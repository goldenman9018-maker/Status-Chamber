package com.example.oneuibottompill

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = 0xFFF4F6F8.toInt()
    private val ink = 0xFF17191C.toInt()
    private val muted = 0xFF6B7178.toInt()
    private val blue = 0xFF2878F0.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(34), dp(22), dp(24))
            setBackgroundColor(bg)
        }

        page.addView(TextView(this).apply {
            text = "One UI Bottom Pill"
            textSize = 26f
            setTextColor(ink)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        })
        page.addView(TextView(this).apply {
            text = "A lightweight Samsung-inspired lock-screen concept"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(8), 0, dp(22))
        })

        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(26), dp(18), dp(26))
            background = rounded(0xFF111315.toInt(), 28)
        }
        preview.addView(TextView(this).apply {
            text = "9:41"
            textSize = 42f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        })
        preview.addView(TextView(this).apply {
            text = "THURSDAY  •  OCTOBER 22"
            textSize = 11f
            letterSpacing = 0.08f
            setTextColor(0xFFB7BDC5.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(30))
        })
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(0xFF292C31.toInt(), 30)
        }
        val dot = TextView(this).apply {
            text = "♪"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
        }
        pill.addView(dot)
        pill.addView(TextView(this).apply {
            text = "  Now playing\n  Ready for music"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        pill.addView(TextView(this).apply {
            text = "Ⅱ"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
        })
        preview.addView(pill, LinearLayout.LayoutParams(-1, -2))
        page.addView(preview)

        page.addView(TextView(this).apply {
            text = "Try the lock-screen demo"
            textSize = 18f
            setTextColor(ink)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(26), 0, dp(8))
        })
        page.addView(TextView(this).apply {
            text = "This opens a sample screen over the keyguard when Android permits it. It does not unlock your phone or replace your system lock screen."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, 0, 0, dp(16))
        })

        val launch = Button(this).apply {
            text = "Open bottom pill demo"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue))
            setOnClickListener { startActivity(Intent(this@MainActivity, PillActivity::class.java)) }
        }
        page.addView(launch, LinearLayout.LayoutParams(-1, dp(52)))

        page.addView(TextView(this).apply {
            text = "Device-friendly • No overlay permission • No background service"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(18), 0, 0)
        })
        setContentView(page)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
}
