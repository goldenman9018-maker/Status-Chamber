package com.example.oneuibottompill

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class PillActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show this sample Activity above the keyguard when launched, without dismissing it.
        if (android.os.Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)

        window.statusBarColor = Color.rgb(14, 16, 19)
        window.navigationBarColor = Color.rgb(14, 16, 19)
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(60), dp(24), dp(20))
            setBackgroundColor(Color.rgb(14, 16, 19))
        }

        root.addView(TextView(this).apply {
            text = "9:41"
            textSize = 58f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        })
        root.addView(TextView(this).apply {
            text = "THURSDAY  •  OCTOBER 22"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(Color.rgb(174, 181, 190))
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(18))
        })
        root.addView(TextView(this).apply {
            text = "Swipe up to unlock"
            textSize = 14f
            setTextColor(Color.rgb(174, 181, 190))
            gravity = Gravity.CENTER
        })

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(15), dp(18), dp(15))
            background = GradientDrawable().apply {
                setColor(Color.rgb(42, 45, 50))
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), Color.rgb(65, 69, 76))
            }
        }
        pill.addView(TextView(this).apply {
            text = "♫"
            textSize = 23f
            setTextColor(Color.WHITE)
        })
        pill.addView(TextView(this).apply {
            text = "  NOW PLAYING\n  Waiting for music"
            textSize = 13f
            setTextColor(Color.WHITE)
            setLineSpacing(dp(2).toFloat(), 1f)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        pill.addView(TextView(this).apply {
            text = "Ⅱ"
            textSize = 20f
            setTextColor(Color.WHITE)
        })
        root.addView(pill, LinearLayout.LayoutParams(-1, -2))

        root.addView(TextView(this).apply {
            text = "DEMO  •  Tap Back to return"
            textSize = 11f
            setTextColor(Color.rgb(130, 137, 146))
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(4))
        })
        setContentView(root)
    }
}
