# One UI Bottom Pill — Android starter

A small Kotlin starter project for a Samsung One UI-inspired bottom live-activity pill concept.

## Important Android limitation

This project is a **visual prototype**, not a replacement for the phone's system lock screen. Android 13 does not let ordinary apps permanently insert a custom view at a fixed position on the stock lock screen. Samsung's Now Bar has deeper system integration that third-party apps do not have.

The demo Activity calls `setShowWhenLocked(true)`, so when launched it may appear above the keyguard without dismissing it. Whether that works exactly as intended depends on the phone's firmware and security settings. It does not automatically appear whenever the phone locks.

## Build

1. Open this folder in Android Studio (recent version).
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated debug APK on your Android phone.

No overlay permission or background service is used, to keep the prototype lightweight for a 2 GB RAM phone.

## Next development steps

- Replace the sample time/date with real values.
- Add a media session integration for actual playback metadata and controls.
- Add an ongoing notification as the reliable Android-supported lock-screen fallback. The phone's notification settings decide whether and where it appears.
- Test on the exact Hisense firmware before relying on keyguard behavior.
